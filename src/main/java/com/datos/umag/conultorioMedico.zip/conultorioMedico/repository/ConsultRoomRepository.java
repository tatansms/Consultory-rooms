package com.datos.umag.conultorioMedico.repository;



import com.datos.umag.conultorioMedico.model.ConsultRoom;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsultRoomRepository extends JpaRepository<ConsultRoom, Long> {
}
