package com.datos.umag.conultorioMedico.dto;

public class AdminDTO {
}
