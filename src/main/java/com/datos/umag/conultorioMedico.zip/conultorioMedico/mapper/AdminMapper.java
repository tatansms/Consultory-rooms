package com.datos.umag.conultorioMedico.mapper;

public class AdminMapper {
}
