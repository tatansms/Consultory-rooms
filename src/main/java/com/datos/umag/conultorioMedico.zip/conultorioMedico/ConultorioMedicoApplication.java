package com.datos.umag.conultorioMedico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConultorioMedicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConultorioMedicoApplication.class, args);
	}

}
